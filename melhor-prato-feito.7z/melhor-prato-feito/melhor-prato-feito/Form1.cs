﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace melhor_prato_feito
{
    public partial class frmPrincipal : Form
    {
        public struct alimento
        {
            public double preco, valorCalorico;
            public string nome;
        }

        int i = 0;
        const int MAX = 3;
        alimento[] tipoAlimento = new alimento[MAX];

        public frmPrincipal()
        {
            InitializeComponent();
            preCadastroAlimento(tipoAlimento);
            lblNomeAlimento.Text = Convert.ToString(tipoAlimento[0].nome);
        }

        public void preCadastroAlimento(alimento[] tipoAlimento)
        {
            //Categoria de Entrada
            tipoAlimento[0].nome = "Arroz";
            tipoAlimento[0].valorCalorico = 130;
            tipoAlimento[0].preco = 0;
            lstAlimestos.Items.Add("0 - Arroz 130Kcal");
            
            tipoAlimento[1].nome = "Feijão";
            tipoAlimento[1].valorCalorico = 76;
            tipoAlimento[1].preco = 0;
            lstAlimestos.Items.Add("1 - Feijão 76Kcal");

            tipoAlimento[2].nome = "Macarrão";
            tipoAlimento[2].valorCalorico = 154;
            tipoAlimento[2].preco = 0;
            lstAlimestos.Items.Add("2 - Macarrão 154Kcal");

            //Mistura          
            tipoAlimento[3].nome = "Alcatra assada";
            tipoAlimento[3].valorCalorico = 206;
            tipoAlimento[3].preco = 0;
            lstAlimestos.Items.Add("3 - Alcatra assada 206Kcal");

            tipoAlimento[4].nome = "Alcatra frita";
            tipoAlimento[4].valorCalorico = 235;
            tipoAlimento[4].preco = 0;
            lstAlimestos.Items.Add("4 - Alcatra assada 235Kcal");

            tipoAlimento[5].nome = "Bacon fatiado";
            tipoAlimento[5].valorCalorico = 314;
            tipoAlimento[5].preco = 0;
            lstAlimestos.Items.Add("5 - Bacon fatiado 314Kcal");

            tipoAlimento[6].nome = "Almôndega de carne";
            tipoAlimento[6].valorCalorico = 203;
            tipoAlimento[6].preco = 0;
            lstAlimestos.Items.Add("6 - Almôndega de carne 203Kcal");

            tipoAlimento[7].nome = "Bisteca de porco";
            tipoAlimento[7].valorCalorico = 337;
            tipoAlimento[7].preco = 0;
            lstAlimestos.Items.Add("7 - Bisteca de porco 337Kcal");

            tipoAlimento[8].nome = "Costelinha de porco";
            tipoAlimento[8].valorCalorico = 483;
            tipoAlimento[8].preco = 0;
            lstAlimestos.Items.Add("8 - Costelinha de porco 483Kcal");
            
            tipoAlimento[9].nome = "Coxa de frango assada";
            tipoAlimento[9].valorCalorico = 110;
            tipoAlimento[9].preco = 0;
            lstAlimestos.Items.Add("9 - Coxa de frango assada 110Kcal");

            tipoAlimento[10].nome = "Coxa de frango cozida";
            tipoAlimento[10].valorCalorico = 120;
            tipoAlimento[10].preco = 0;
            lstAlimestos.Items.Add("10 - Coxa de frango cozida 120Kcal");

            tipoAlimento[11].nome = "Cupim assado";
            tipoAlimento[11].valorCalorico = 250;
            tipoAlimento[11].preco = 0;
            lstAlimestos.Items.Add("11 - Cupim assado 250Kcal");

            tipoAlimento[12].nome = "Fígado bovino frito";
            tipoAlimento[12].valorCalorico = 210;
            tipoAlimento[12].preco = 0;
            lstAlimestos.Items.Add("12 - Fígado bovino frito 210Kcal");

            tipoAlimento[13].nome = "Filé de frango frito";
            tipoAlimento[13].valorCalorico = 139;
            tipoAlimento[13].preco = 0;
            lstAlimestos.Items.Add("13 - Filé de frango frito 139Kcal");

            tipoAlimento[14].nome = "Hamburger ao sugo";
            tipoAlimento[14].valorCalorico = 242;
            tipoAlimento[14].preco = 0;
            lstAlimestos.Items.Add("14 - Hamburger ao sugo 242Kcal");

            tipoAlimento[15].nome = "Maminha assada";
            tipoAlimento[15].valorCalorico = 141;
            tipoAlimento[15].preco = 0;
            lstAlimestos.Items.Add("15 - Maminha assada 141Kcal");

            tipoAlimento[16].nome = "Músculo cozido";
            tipoAlimento[16].valorCalorico = 180;
            tipoAlimento[16].preco = 0;
            lstAlimestos.Items.Add("16 - Músculo cozido 180Kcal");

            tipoAlimento[17].nome = "Peito de frango sem pele";
            tipoAlimento[17].valorCalorico = 100;
            tipoAlimento[17].preco = 0;
            lstAlimestos.Items.Add("17 - Peito de frango sem pele 100Kcal");

            tipoAlimento[18].nome = "Linguiça assada";
            tipoAlimento[18].valorCalorico = 255;
            tipoAlimento[18].preco = 0;
            lstAlimestos.Items.Add("18 - Linguiça assada 255Kcal");

            //Guarnição
            tipoAlimento[19].nome = "Farofa";
            tipoAlimento[19].valorCalorico = 169;
            tipoAlimento[19].preco = 0;
            lstAlimestos.Items.Add("19 - Farofa 169Kcal");

            tipoAlimento[20].nome = "Mandioca Frita";
            tipoAlimento[20].valorCalorico = 352;
            tipoAlimento[20].preco = 0;
            lstAlimestos.Items.Add("20 - Mandioca frita 169Kcal");

            tipoAlimento[21].nome = "Batata frita";
            tipoAlimento[21].valorCalorico = 314;
            tipoAlimento[21].preco = 0;
            lstAlimestos.Items.Add("21 - Batata frita 314Kcal");

            tipoAlimento[22].nome = "Batata doce frita";
            tipoAlimento[22].valorCalorico = 383;
            tipoAlimento[22].preco = 0;
            lstAlimestos.Items.Add("22 - Batata doce frita 383Kcal");

            tipoAlimento[23].nome = "Beringela ao molho branco";
            tipoAlimento[23].valorCalorico = 196;
            tipoAlimento[23].preco = 0;
            lstAlimestos.Items.Add("23 - Beringela ao molho branco 196Kcal");

            //Salada
            tipoAlimento[24].nome = "Alface";
            tipoAlimento[24].valorCalorico = 20;
            tipoAlimento[24].preco = 0;
            lstAlimestos.Items.Add("24 - Alface 20Kcal");

            tipoAlimento[25].nome = "Tomate";
            tipoAlimento[25].valorCalorico = 20;
            tipoAlimento[25].preco = 0;
            lstAlimestos.Items.Add("25 - Tomate 20Kcal");

            tipoAlimento[26].nome = "Vagem cozida";
            tipoAlimento[26].valorCalorico = 52;
            tipoAlimento[26].preco = 0;
            lstAlimestos.Items.Add("24 - Vagem cozida 20Kcal");

            tipoAlimento[27].nome = "Cenoura cozida com couve-flor";
            tipoAlimento[27].valorCalorico = 48;
            tipoAlimento[27].preco = 0;
            lstAlimestos.Items.Add("27 - Cenoura cozida com couve-flor 48Kcal");

            tipoAlimento[28].nome = "Beterraba";
            tipoAlimento[28].valorCalorico = 55;
            tipoAlimento[28].preco = 0;
            lstAlimestos.Items.Add("28 - Beterraba 55Kcal");

        }
        public void limpar()
        {
            lblNomeAlimento.Text = "Alimento";
            mskAlimento.Text = "";
        }
        public void ativaCadastroPreco()
        {
            limpar();
            txtAlimento.Enabled = true;
            btnCadastraPreco.Enabled = true;
            btnIndicarPrato.Enabled = false;
            i = 0;
        }
        public void desativaCadastroPreco()
        {
            limpar();
            txtAlimento.Enabled = false;
            btnCadastraPreco.Enabled = false;
            btnIndicarPrato.Enabled = true;
        }
        public void exibePreco()
        {
            lbl0.Text = tipoAlimento[0].nome + ": R$" + Convert.ToString(tipoAlimento[0].preco);
            lbl1.Text = tipoAlimento[1].nome + ": R$" + Convert.ToString(tipoAlimento[1].preco);
            lbl2.Text = tipoAlimento[2].nome + ": R$" + Convert.ToString(tipoAlimento[2].preco);
        }
        public void cadastraPreco()
        {
            if (txtAlimento.Text == "")
            {
                MessageBox.Show("Insira o preço do Alimento, caso não queira o alimento insira 0 (Zero).");
            }
            else
            {
                tipoAlimento[i].preco = double.Parse(txtAlimento.Text);
                i++;

                limpar();
                if (i < MAX)
                {
                    lblNomeAlimento.Text = Convert.ToString(tipoAlimento[i].nome);
                }
                else
                {
                    MessageBox.Show("Todos Alimentos Inseridos, Clique em Indicar Prato!");
                    desativaCadastroPreco();
                    exibePreco();
                }
            }
        }
        private void btnCadastraPreco_Click(object sender, EventArgs e)
        {
            cadastraPreco();
        }

        private void btnRecomecar_Click(object sender, EventArgs e)
        {
            limpar();
            ativaCadastroPreco();
            lblNomeAlimento.Text = Convert.ToString(tipoAlimento[0].nome);
        }
    }
}
