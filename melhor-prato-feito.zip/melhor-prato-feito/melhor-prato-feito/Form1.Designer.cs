﻿namespace melhor_prato_feito
{
    partial class frmCadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.mskAlimento = new System.Windows.Forms.MaskedTextBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnRecomecar = new System.Windows.Forms.Button();
            this.lblNomeAlimento = new System.Windows.Forms.Label();
            this.btnCadastraPreco = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lstAlimentos = new System.Windows.Forms.ListBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabMelhorPrato = new System.Windows.Forms.TabPage();
            this.tabCadastroAlimento = new System.Windows.Forms.TabPage();
            this.btnIndicarPrato = new System.Windows.Forms.Button();
            this.lstPrato = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabMelhorPrato.SuspendLayout();
            this.tabCadastroAlimento.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.mskAlimento);
            this.groupBox1.Controls.Add(this.btnRecomecar);
            this.groupBox1.Controls.Add(this.lblNomeAlimento);
            this.groupBox1.Controls.Add(this.btnCadastraPreco);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(232, 115);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cadastro de Preço";
            // 
            // mskAlimento
            // 
            this.mskAlimento.Location = new System.Drawing.Point(9, 31);
            this.mskAlimento.Mask = "$ 00,00";
            this.mskAlimento.Name = "mskAlimento";
            this.mskAlimento.Size = new System.Drawing.Size(100, 20);
            this.mskAlimento.TabIndex = 3;
            this.mskAlimento.Text = "0000";
            // 
            // btnSair
            // 
            this.btnSair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSair.Location = new System.Drawing.Point(84, 80);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(72, 23);
            this.btnSair.TabIndex = 5;
            this.btnSair.Text = "&Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnRecomecar
            // 
            this.btnRecomecar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRecomecar.Location = new System.Drawing.Point(138, 57);
            this.btnRecomecar.Name = "btnRecomecar";
            this.btnRecomecar.Size = new System.Drawing.Size(88, 52);
            this.btnRecomecar.TabIndex = 6;
            this.btnRecomecar.Text = "&Recomeçar";
            this.btnRecomecar.UseVisualStyleBackColor = true;
            this.btnRecomecar.Click += new System.EventHandler(this.btnRecomecar_Click);
            // 
            // lblNomeAlimento
            // 
            this.lblNomeAlimento.AutoSize = true;
            this.lblNomeAlimento.Location = new System.Drawing.Point(6, 15);
            this.lblNomeAlimento.Name = "lblNomeAlimento";
            this.lblNomeAlimento.Size = new System.Drawing.Size(47, 13);
            this.lblNomeAlimento.TabIndex = 1;
            this.lblNomeAlimento.Text = "Alimento";
            // 
            // btnCadastraPreco
            // 
            this.btnCadastraPreco.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnCadastraPreco.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadastraPreco.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnCadastraPreco.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnCadastraPreco.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
            this.btnCadastraPreco.Location = new System.Drawing.Point(9, 57);
            this.btnCadastraPreco.Name = "btnCadastraPreco";
            this.btnCadastraPreco.Size = new System.Drawing.Size(123, 52);
            this.btnCadastraPreco.TabIndex = 0;
            this.btnCadastraPreco.Text = "&Cadastrar Preço";
            this.btnCadastraPreco.UseVisualStyleBackColor = false;
            this.btnCadastraPreco.Click += new System.EventHandler(this.btnCadastraPreco_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.lstAlimentos);
            this.groupBox2.Location = new System.Drawing.Point(6, 127);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(232, 264);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Alimentos";
            // 
            // lstAlimentos
            // 
            this.lstAlimentos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lstAlimentos.FormattingEnabled = true;
            this.lstAlimentos.Location = new System.Drawing.Point(6, 19);
            this.lstAlimentos.Name = "lstAlimentos";
            this.lstAlimentos.Size = new System.Drawing.Size(220, 238);
            this.lstAlimentos.TabIndex = 0;
            this.lstAlimentos.SelectedIndexChanged += new System.EventHandler(this.lstAlimentos_SelectedIndexChanged);
            this.lstAlimentos.DoubleClick += new System.EventHandler(this.lstAlimentos_DoubleClick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabMelhorPrato);
            this.tabControl1.Controls.Add(this.tabCadastroAlimento);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(338, 424);
            this.tabControl1.TabIndex = 11;
            // 
            // tabMelhorPrato
            // 
            this.tabMelhorPrato.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabMelhorPrato.Controls.Add(this.button1);
            this.tabMelhorPrato.Controls.Add(this.lstPrato);
            this.tabMelhorPrato.Controls.Add(this.btnIndicarPrato);
            this.tabMelhorPrato.Controls.Add(this.btnSair);
            this.tabMelhorPrato.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabMelhorPrato.Location = new System.Drawing.Point(4, 22);
            this.tabMelhorPrato.Name = "tabMelhorPrato";
            this.tabMelhorPrato.Padding = new System.Windows.Forms.Padding(3);
            this.tabMelhorPrato.Size = new System.Drawing.Size(330, 398);
            this.tabMelhorPrato.TabIndex = 0;
            this.tabMelhorPrato.Text = "Melhor Prato";
            this.tabMelhorPrato.UseVisualStyleBackColor = true;
            this.tabMelhorPrato.Click += new System.EventHandler(this.tabMelhorPrato_Click);
            // 
            // tabCadastroAlimento
            // 
            this.tabCadastroAlimento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabCadastroAlimento.Controls.Add(this.groupBox1);
            this.tabCadastroAlimento.Controls.Add(this.groupBox2);
            this.tabCadastroAlimento.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabCadastroAlimento.Location = new System.Drawing.Point(4, 22);
            this.tabCadastroAlimento.Name = "tabCadastroAlimento";
            this.tabCadastroAlimento.Padding = new System.Windows.Forms.Padding(3);
            this.tabCadastroAlimento.Size = new System.Drawing.Size(330, 398);
            this.tabCadastroAlimento.TabIndex = 1;
            this.tabCadastroAlimento.Text = "Cadastro do Alimento";
            this.tabCadastroAlimento.UseVisualStyleBackColor = true;
            this.tabCadastroAlimento.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // btnIndicarPrato
            // 
            this.btnIndicarPrato.Location = new System.Drawing.Point(84, 31);
            this.btnIndicarPrato.Name = "btnIndicarPrato";
            this.btnIndicarPrato.Size = new System.Drawing.Size(139, 43);
            this.btnIndicarPrato.TabIndex = 6;
            this.btnIndicarPrato.Text = "&Indicar Prato";
            this.btnIndicarPrato.UseVisualStyleBackColor = true;
            this.btnIndicarPrato.Click += new System.EventHandler(this.btnIndicarPrato_Click);
            // 
            // lstPrato
            // 
            this.lstPrato.FormattingEnabled = true;
            this.lstPrato.Location = new System.Drawing.Point(84, 123);
            this.lstPrato.Name = "lstPrato";
            this.lstPrato.Size = new System.Drawing.Size(139, 160);
            this.lstPrato.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(162, 80);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(61, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "&Ajuda";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmCadastro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::melhor_prato_feito.Properties.Resources.prato;
            this.ClientSize = new System.Drawing.Size(652, 442);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmCadastro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Melhor Prato Feito";
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabMelhorPrato.ResumeLayout(false);
            this.tabCadastroAlimento.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblNomeAlimento;
        private System.Windows.Forms.Button btnCadastraPreco;
        private System.Windows.Forms.MaskedTextBox mskAlimento;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnRecomecar;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lstAlimentos;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabMelhorPrato;
        private System.Windows.Forms.TabPage tabCadastroAlimento;
        private System.Windows.Forms.Button btnIndicarPrato;
        private System.Windows.Forms.ListBox lstPrato;
        private System.Windows.Forms.Button button1;
    }
}

