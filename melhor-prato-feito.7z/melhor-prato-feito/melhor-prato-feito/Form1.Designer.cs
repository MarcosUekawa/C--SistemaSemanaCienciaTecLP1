﻿namespace melhor_prato_feito
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.mskAlimento = new System.Windows.Forms.MaskedTextBox();
            this.txtAlimento = new System.Windows.Forms.TextBox();
            this.lblNomeAlimento = new System.Windows.Forms.Label();
            this.btnCadastraPreco = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblCouve = new System.Windows.Forms.Label();
            this.lblBrocolis = new System.Windows.Forms.Label();
            this.lblCarneBranca = new System.Windows.Forms.Label();
            this.lblCarneVermelha = new System.Windows.Forms.Label();
            this.lblMacarrao = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl0 = new System.Windows.Forms.Label();
            this.btnIndicarPrato = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnRecomecar = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lstAlimestos = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.mskAlimento);
            this.groupBox1.Controls.Add(this.txtAlimento);
            this.groupBox1.Controls.Add(this.lblNomeAlimento);
            this.groupBox1.Controls.Add(this.btnCadastraPreco);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(170, 115);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Informe o Preço";
            // 
            // mskAlimento
            // 
            this.mskAlimento.Location = new System.Drawing.Point(15, 38);
            this.mskAlimento.Mask = "$ 00,00";
            this.mskAlimento.Name = "mskAlimento";
            this.mskAlimento.Size = new System.Drawing.Size(100, 20);
            this.mskAlimento.TabIndex = 3;
            this.mskAlimento.Text = "2222";
            // 
            // txtAlimento
            // 
            this.txtAlimento.Location = new System.Drawing.Point(64, 15);
            this.txtAlimento.Name = "txtAlimento";
            this.txtAlimento.Size = new System.Drawing.Size(100, 20);
            this.txtAlimento.TabIndex = 3;
            // 
            // lblNomeAlimento
            // 
            this.lblNomeAlimento.AutoSize = true;
            this.lblNomeAlimento.Location = new System.Drawing.Point(12, 22);
            this.lblNomeAlimento.Name = "lblNomeAlimento";
            this.lblNomeAlimento.Size = new System.Drawing.Size(47, 13);
            this.lblNomeAlimento.TabIndex = 1;
            this.lblNomeAlimento.Text = "Alimento";
            // 
            // btnCadastraPreco
            // 
            this.btnCadastraPreco.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnCadastraPreco.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadastraPreco.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnCadastraPreco.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnCadastraPreco.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
            this.btnCadastraPreco.Location = new System.Drawing.Point(15, 76);
            this.btnCadastraPreco.Name = "btnCadastraPreco";
            this.btnCadastraPreco.Size = new System.Drawing.Size(130, 23);
            this.btnCadastraPreco.TabIndex = 0;
            this.btnCadastraPreco.Text = "&Cadastrar Preço";
            this.btnCadastraPreco.UseVisualStyleBackColor = false;
            this.btnCadastraPreco.Click += new System.EventHandler(this.btnCadastraPreco_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblCouve);
            this.groupBox2.Controls.Add(this.lblBrocolis);
            this.groupBox2.Controls.Add(this.lblCarneBranca);
            this.groupBox2.Controls.Add(this.lblCarneVermelha);
            this.groupBox2.Controls.Add(this.lblMacarrao);
            this.groupBox2.Controls.Add(this.lbl2);
            this.groupBox2.Controls.Add(this.lbl1);
            this.groupBox2.Controls.Add(this.lbl0);
            this.groupBox2.Location = new System.Drawing.Point(12, 142);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(170, 231);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Preços Cadastrados";
            // 
            // lblCouve
            // 
            this.lblCouve.AutoSize = true;
            this.lblCouve.Location = new System.Drawing.Point(7, 185);
            this.lblCouve.Name = "lblCouve";
            this.lblCouve.Size = new System.Drawing.Size(44, 13);
            this.lblCouve.TabIndex = 7;
            this.lblCouve.Text = "Couve: ";
            // 
            // lblBrocolis
            // 
            this.lblBrocolis.AutoSize = true;
            this.lblBrocolis.Location = new System.Drawing.Point(7, 162);
            this.lblBrocolis.Name = "lblBrocolis";
            this.lblBrocolis.Size = new System.Drawing.Size(50, 13);
            this.lblBrocolis.TabIndex = 6;
            this.lblBrocolis.Text = "Brócolis: ";
            // 
            // lblCarneBranca
            // 
            this.lblCarneBranca.AutoSize = true;
            this.lblCarneBranca.Location = new System.Drawing.Point(6, 137);
            this.lblCarneBranca.Name = "lblCarneBranca";
            this.lblCarneBranca.Size = new System.Drawing.Size(78, 13);
            this.lblCarneBranca.TabIndex = 5;
            this.lblCarneBranca.Text = "Carne Branca: ";
            // 
            // lblCarneVermelha
            // 
            this.lblCarneVermelha.AutoSize = true;
            this.lblCarneVermelha.Location = new System.Drawing.Point(6, 114);
            this.lblCarneVermelha.Name = "lblCarneVermelha";
            this.lblCarneVermelha.Size = new System.Drawing.Size(85, 13);
            this.lblCarneVermelha.TabIndex = 4;
            this.lblCarneVermelha.Text = "Carne Vermelha:";
            // 
            // lblMacarrao
            // 
            this.lblMacarrao.AutoSize = true;
            this.lblMacarrao.Location = new System.Drawing.Point(7, 90);
            this.lblMacarrao.Name = "lblMacarrao";
            this.lblMacarrao.Size = new System.Drawing.Size(58, 13);
            this.lblMacarrao.TabIndex = 3;
            this.lblMacarrao.Text = "Macarrão: ";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(7, 65);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(47, 13);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "Alimento";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(6, 42);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(47, 13);
            this.lbl1.TabIndex = 1;
            this.lbl1.Text = "Alimento";
            // 
            // lbl0
            // 
            this.lbl0.AutoSize = true;
            this.lbl0.Location = new System.Drawing.Point(7, 20);
            this.lbl0.Name = "lbl0";
            this.lbl0.Size = new System.Drawing.Size(47, 13);
            this.lbl0.TabIndex = 0;
            this.lbl0.Text = "Alimento";
            // 
            // btnIndicarPrato
            // 
            this.btnIndicarPrato.Enabled = false;
            this.btnIndicarPrato.Location = new System.Drawing.Point(201, 15);
            this.btnIndicarPrato.Name = "btnIndicarPrato";
            this.btnIndicarPrato.Size = new System.Drawing.Size(134, 55);
            this.btnIndicarPrato.TabIndex = 4;
            this.btnIndicarPrato.Text = "&Indicar Prato";
            this.btnIndicarPrato.UseVisualStyleBackColor = true;
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(282, 75);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(53, 23);
            this.btnSair.TabIndex = 5;
            this.btnSair.Text = "&Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            // 
            // btnRecomecar
            // 
            this.btnRecomecar.Location = new System.Drawing.Point(201, 75);
            this.btnRecomecar.Name = "btnRecomecar";
            this.btnRecomecar.Size = new System.Drawing.Size(75, 23);
            this.btnRecomecar.TabIndex = 6;
            this.btnRecomecar.Text = "&Recomeçar";
            this.btnRecomecar.UseVisualStyleBackColor = true;
            this.btnRecomecar.Click += new System.EventHandler(this.btnRecomecar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::melhor_prato_feito.Properties.Resources.nutrientes_dos_alimentos;
            this.pictureBox1.Location = new System.Drawing.Point(282, 26);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(464, 347);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // lstAlimestos
            // 
            this.lstAlimestos.FormattingEnabled = true;
            this.lstAlimestos.Location = new System.Drawing.Point(215, 150);
            this.lstAlimestos.Name = "lstAlimestos";
            this.lstAlimestos.Size = new System.Drawing.Size(120, 95);
            this.lstAlimestos.TabIndex = 7;
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(716, 385);
            this.Controls.Add(this.lstAlimestos);
            this.Controls.Add(this.btnRecomecar);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnIndicarPrato);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prato do Dia";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblNomeAlimento;
        private System.Windows.Forms.Button btnCadastraPreco;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblCouve;
        private System.Windows.Forms.Label lblBrocolis;
        private System.Windows.Forms.Label lblCarneBranca;
        private System.Windows.Forms.Label lblCarneVermelha;
        private System.Windows.Forms.Label lblMacarrao;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl0;
        private System.Windows.Forms.MaskedTextBox mskAlimento;
        private System.Windows.Forms.TextBox txtAlimento;
        private System.Windows.Forms.Button btnIndicarPrato;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnRecomecar;
        private System.Windows.Forms.ListBox lstAlimestos;
    }
}

