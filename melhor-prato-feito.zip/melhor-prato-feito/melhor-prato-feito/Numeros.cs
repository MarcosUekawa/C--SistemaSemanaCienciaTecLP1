﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace melhor_prato_feito
{
    public class Numeros
    {
        /*private static struct alimento
        {
            public double valorCalorico, precoKcal;
            public string preco, nome;
        }
        private const int MAX = 29;
        private alimento[] tipoAlimento = new alimento[MAX];

        private static struct tipoAlimento 
        {
            get { return preco; }
            set { preco = value }

        }*/
    }
}
